class Carro{
    //Propiedades
    marca
    placa
    mostrar(){
        
    }
    mostrar(){

    }
}
const carro= new Carro()
carro.marca ="perro"
console.log(carro.marca)