class Persona{
    nombre
    apellido
    documento
    edad
     constructor(nombre){
        this.nombre = nombre
    }
    registrar(){

    }
    actualizar(){

    }

}
const persona = new Persona("ñamm")
persona.nombre 
console.log(persona.nombre)
