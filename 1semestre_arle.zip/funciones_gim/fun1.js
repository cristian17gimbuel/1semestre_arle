//Determinar suma de una multiplicacion de dos numeros
//Mostrar de manera sencilla
const mostrar=(a, b)=>{
    let multiplicacion1= a*b
    return multiplicacion1

}
const resultado = mostrar(2,3)
console.log(`La multiplicacion es: ${resultado}`)
//
const mostrar1=(a, b)=>{
    let multiplicacion2= a*b
    return `La multiplicación de ${a} y ${b} es: ${multiplicacion2}`

}
console.log (mostrar1(6,7))

//ahora la suma de los dos numeros
const mostar2= (a,b)=>{
    let suma= a+b
    return `La suma de ${a} y ${b} es: ${suma}`
}
console.log(mostar2(10,45))