//Dterminar entre dos numeros ingresado cual es el mas mayor
const mayorNumero = (a, b) => `El número mayor entre ${a} y ${b} es: ${a > b ? a : b}`;
console.log(mayorNumero(40, 15));
