// Definimos el valor base de la matrícula
const valorBase = 7000000;
let opcionPago = 2
let totalPagar
let cuotas
let saldo
let interes = 0.02
let intentos = 0
while (intentos < 1) {
    if (opcionPago === 1) {
        totalPagar = valorBase * 0.95
        console.log(`Pago completo seleccionado. Total a pagar: $${totalPagar}`)
    } else if (opcionPago === 2) {
        saldo = valorBase
        cuotas = 2
        totalPagar = 0
        for (let i = 0; i < cuotas; i++) {
            saldo += saldo * interes
        }
        totalPagar = saldo / cuotas
        console.log(`Pago en 2 cuotas seleccionado. Valor por cuota: $${totalPagar.toFixed(2)}`)
    } else if (opcionPago === 3) {
        saldo = valorBase
        cuotas = 3
        totalPagar = 0
        for (let i = 0; i < cuotas; i++) {
            saldo += saldo * interes
        }
        totalPagar = saldo / cuotas
        console.log(`Pago en 3 cuotas seleccionado. Valor por cuota: $${totalPagar.toFixed(2)}`)
    } else {
        console.log("Opción inválida. Seleccione una opción entre 1 y 3.")
    }
    intentos++
}