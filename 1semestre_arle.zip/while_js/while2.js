
function calcularBoletas(cantidad, localidad) {
    let precios = {
      "General": 50000,
      "Preferencial": 150000,
      "VIP": 300000
    };
  
    let precioBase = precios[localidad] * cantidad;
    let impuestos = precioBase * 0.10;
    let cargoServicio = 5000 * cantidad;
    let total = precioBase + impuestos + cargoServicio;
  
    return `
      Desglose de cobros:
      - Precio de las boletas: $${precioBase}
      - Impuestos (10%): $${impuestos}
      - Cargo por servicio (${cantidad} boletas): $${cargoServicio}
      Total a pagar: $${total}
    `;
  }
  
  // Ejemplo de uso:
  let cantidadBoletas = 3; // Ejemplo: 3 boletas
  let localidadSeleccionada = "Preferencial"; // Ejemplo: "Preferencial"
  console.log(calcularBoletas(cantidadBoletas, localidadSeleccionada));
  