//Alquiler de libros
 // "Bestsellers", "Literatura", "Académicos"
let categoria = "Bestsellers";
let dias = 9;
let libros = 3;
let precioDia = 0;
let total = 0;

if (dias < 1 || dias > 30) {
    console.log("Días inválidos");
} else if (libros < 1 || libros > 5) {
    console.log("Cantidad de libros inválida");
} else {
    if (categoria === "Bestsellers") precioDia = 500;
    else if (categoria === "Literatura") precioDia = 100;
    else if (categoria === "Académicos") precioDia = 0;
    else console.log("Categoría inválida");

    if (precioDia >= 0) {
        total = precioDia * dias * libros;
        if (dias > 10 && precioDia > 0) {
            total *= 0.8; // 10% de descuento
        }
        console.log("Total a pagar: $" + total);
    }
}

