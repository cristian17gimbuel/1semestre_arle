//Manejo de ventilador
let velocidad1=false
let velocidad2=true
let velocidad3=false
if(velocidad1){
    console.log(`L a velocidad del ventilador esta en el primer nivel`)
}else if(velocidad2){
    console.log(`L avelocidad del ventilador esta en el nivel 2`)
}else if(velocidad3){
    console.log(`La velocidad del ventilador esta en el nivel 3`)
}else{
    console.log(`Por favor encienda el ventidalor `)
}