//Funcionamiento de aire acondicionado
let aireacondi= true
let nivel=2
if (aireacondi){
    console.log(`El aire acondicionado esta encendido`)
}else if(nivel==0){
    console.log(`El aire acondicionado no esta prendido `)
}else if(nivel>0 && aireacondi<=3){
    console.log(`El aire acondicionado esta en el nivel ${nivel} y esta funcionando correctamente `)
}else{
    console.log(`Por favor encienda su aire acondicionado`)
}