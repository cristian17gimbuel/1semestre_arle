//Control de discoteca 
let edad= 18
if (edad>=18){
    console.log(`Su edad es ${edad}años, por lo tanto si puede ingresar a la discoteca`)
}else{
    console.log(`Su edad es ${edad}años, eres menor de edad no puedes ingresar a la discoteca `)
}