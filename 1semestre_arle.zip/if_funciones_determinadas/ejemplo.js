let color = "rojo"
let estadosemaforo = true 
let resultado1 = color == "verde" ? `seguir..`   : color=="rojo" ? `detengase`: color == "amarillo"? `alistarse` :`dañado`
let encentido= estadosemaforo? resultado1 : `El semaforo esta apagado `
console.log(encentido)