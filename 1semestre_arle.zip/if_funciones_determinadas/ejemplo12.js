//Mes del año
let mes="enero"
let año=2025n
if(mes==mes && año==año){
    console.log(`${mes}del año ${año} toca hacer ejercicio`)
}else{
    console.log(`Estaremos pendiente que mes volveremos a hacer ejercicio`)
}