//Ingreso de sena sofia plus
let email="cris@23"
let contraseña=1234n
if (email==email && contraseña==contraseña){
    console.log(`Bienvenido a Sena sofia plus`)
}else{
    console.log(`Querido usuario, alguno de los datos solicitados es incorrecto, vuelve a intentarlo `)
}