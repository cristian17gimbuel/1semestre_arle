//Biblioteca
let libros=[10,23,24,25,40,57,90,100,78,60]
const filtrarlibro=libros.filter(x=> x>50)
console.log("A continuacion se motraran los libro cuyo codigo es mayor a 50")
console.log(filtrarlibro)