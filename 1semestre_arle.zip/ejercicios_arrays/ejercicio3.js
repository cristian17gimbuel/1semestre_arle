//Lista de personas que asistieron a un evento 
let asistentes = new Map([[1, "Andres"], [2, "Luis"]])
const agregarAsistente = (codigo, nombre) => asistentes.set(codigo, nombre)
agregarAsistente(3, "Sofía").set(4,"luisa")
console.log(asistentes)
