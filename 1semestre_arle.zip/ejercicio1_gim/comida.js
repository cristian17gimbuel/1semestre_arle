//Pedido de sándwich
let tamano = "pequeño"
let ingredientes = ["queso","tocineta","jalapeño","pavo"]
if(tamano=="grande ")

