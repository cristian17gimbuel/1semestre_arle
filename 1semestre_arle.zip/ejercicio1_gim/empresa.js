//Pago por horas trabajadas
let hrstrabajadas= 12
let nombre="Pedro"
if (hrstrabajadas>=1 && hrstrabajadas<=10){
    let pagofinal= hrstrabajadas*30000
    console.log(`Hola ${nombre} sus horas trabjadas en la semana es de ${hrstrabajadas}h, por lo tanto cada hora se le pagara a 30.000mil.
    total a pagar: ${pagofinal}mil `)
}else if (hrstrabajadas>10){
    let pagofinal1= hrstrabajadas*33000
    console.log(`Hola ${nombre} sus horas trabjadas en la semana es de ${hrstrabajadas}h, por lo tanto cada hora se le pagara a 33.000mil.
    total a pagar: ${pagofinal1}mil `)
}else{
    console.log(`Usted ${nombre} no esta trabjando en esta empresa`)
}