//Mantenimiento de pc
let emitePitido = true
let discoGira = false

if (emitePitido && discoGira) {
    console.log("Póngase en contacto con el técnico de apoyo")
} else if (emitePitido && !discoGira) {
    console.log("Verificar contactos de la unidad")
} else if (!emitePitido && !discoGira) {
    console.log("Traiga la computadora para repararla en la central.")
} else if (!emitePitido && discoGira) {
    console.log("Compruebe las conexiones de altavoces")
}else{
    console.log(`la pc esta dañada`)
}
