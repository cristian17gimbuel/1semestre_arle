//Determinar si el numero ingresado es par o impar 
if (numero % 2===0){
    console.log(`El ${numero} es par`)
}else{
    console.log(`El ${numero} es impar`)
}