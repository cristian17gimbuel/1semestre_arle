//Calificaciones
let fisica = 8
let quimica = 7
let biologia = 9
let matematicas = 10
let informatica = 6
let sumaCalificaciones = fisica + quimica + biologia + matematicas + informatica
let porcentajeFinal = (sumaCalificaciones / 50) * 100
let rendimiento
if (porcentajeFinal < 60) {
    rendimiento = "Mala"
} else if (porcentajeFinal <= 80) {
    rendimiento = "Buena"
} else {
    rendimiento = "Excelente"
    console.log(`Tu porcentaje final es ${porcentajeFinal.toFixed(2)}% y tu rendimiento es ${rendimiento}.`);
}