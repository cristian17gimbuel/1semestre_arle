// Alquiler de lavadoras
let tipoLavadora = 1
let cantidad = 4
let horas = 5
const costoGrande = 4000
const costoPequena = 3000
let costoPorHora = tipoLavadora === 1 ? costoGrande : costoPequena
let costoTotal = cantidad * horas * costoPorHora
if (cantidad > 3) {
    costoTotal *= 0.97
}
console.log(`Costo total por alquilar ${cantidad} lavadoras tipo ${tipoLavadora} por ${horas} horas: $${costoTotal.toFixed(2)}`)
