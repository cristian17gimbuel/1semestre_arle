//Cálculo de ayuda económica
let genero = "masculino"
let edad = 30
let ayuda = 0
if (genero === "femenino") {
    if (edad > 50) {
        ayuda = 120000
    } else if (edad >= 30) {
        ayuda = 100000
    }
} else if (genero === "masculino") {
    ayuda = 40000
}
console.log(`El valor de ayuda mensual es: $${ayuda}`);