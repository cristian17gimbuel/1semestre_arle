//Venta de gafas 
// 1=Sol, 2=Lectura, 3=Deportiva
let tipoGafa = 1;
let antireflejo = true;
let cantidad = 2;
let precio = 0;

if (cantidad < 1 || cantidad > 10) {
    console.log("Cantidad inválida (1-10)");
} else {
    if (tipoGafa === 1) precio = 50000;
    else if (tipoGafa === 2) precio = 40000;
    else if (tipoGafa === 3) precio = 60000;
    else console.log("Tipo de gafa inválido");

    if (tipoGafa >= 1 && tipoGafa <= 3) {
        if (antireflejo) precio += 8000;
        let total = precio * cantidad;
        console.log("Total a pagar: $" + total);
    }
}
