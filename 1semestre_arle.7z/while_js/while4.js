//venta de postre
function elegirPostre() {
    let postre = "Helado";
    let sabor = "Fresa";
    let cantidad = 3;
    let precioUnitario = 0;
  
    switch (postre) {
      case "Helado":
        precioUnitario = 5000;
        break;
      case "Pastel":
        precioUnitario = 8000;
        break;
      case "Galletas":
        precioUnitario = 3000;
        break;
      default:
        console.log("Postre no válido");
        return;
    }
  
    let total = precioUnitario * cantidad;
  
    console.log(`Elegiste: ${cantidad} ${postre}(s)`);
    console.log(`Sabor: ${sabor}`);
    console.log(`Precio unitario: $${precioUnitario}`);
    console.log(`Total a pagar: $${total}`);
  }
  
  elegirPostre();
  