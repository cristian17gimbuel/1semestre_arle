//venta de libros con descuento
const precioNovela = 30000;
const precioCiencia = 45000;
const precioHistoria = 40000;
let tipoLibro = 1; //tipo de libro
let cantidad = 3;
let total = 0;
let intentos = 0;

while (intentos < 1) {
    if (cantidad < 1 || cantidad > 5) {
        console.log("Cantidad inválida (debe ser entre 1 y 5)");
    } else {
        if (tipoLibro === 1) {
            total = precioNovela * cantidad;
        } else if (tipoLibro === 2) {
            total = precioCiencia * cantidad;
        } else if (tipoLibro === 3) {
            total = precioHistoria * cantidad;
        } else {
            console.log("Tipo de libro inválido");
        }

        if (cantidad >= 3) {
            total *= 0.50; // 15% de descuento
        }

        if (tipoLibro >= 1 && tipoLibro <= 3) {
            console.log(`Total a pagar: $${total.toLocaleString("es-CO")}`);
        }
    }
    intentos++;
}
