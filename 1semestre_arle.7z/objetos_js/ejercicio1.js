//Biblioteca para hacerlo con objetos
const arraylibros=[
    {libro:"San Pedro", id:28 , ocupado:true},
    {libro:"Transformers", id:30 , ocupado:true},
    {libro:"El lobo", id:3 , ocupado:true}
]
    

let buscar=arraylibros.filter(x => x.id > 10)
console.log(buscar)