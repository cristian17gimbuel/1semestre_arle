//Evento, listado de personas con objetos
const arrayevento=[
    {nombre:"andres", id: 1 },
    {nombre:"andrea", id: 5},
    {nombre:"jose", id: 10},
    {nombre:"karina", id: 11},
    {nombre:"angie", id: 71},
    {nombre:"marta", id: 90},
]
let buscar=arrayevento.filter(x => x.id < 10)
console.log(buscar) 