//Tienda con objetos
const arraytienda=[
    {producto:"galletas", id:1 , disponible:true},
    {producto:"papas", id:20 , disponible:true},
    {producto:"bombom", id:15 , disponible:true},
    {producto:"barrilete", id:8 , disponible:true},
    {producto:"menta", id:28 , disponible:false},
    {producto:"gaseosa", id:51 , disponible:true},
]
let buscar=arraytienda.filter(x => x.id > 20 && x.disponible === true)
console.log(buscar)