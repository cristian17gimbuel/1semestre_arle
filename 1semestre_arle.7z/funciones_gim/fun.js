// Función tradicional para determinar cuántos números son divisibles por 3 del 1 al 20
function numerosDivisiblesPorTres() {
    let contador = 0;  // Para contar cuántos números son divisibles por 3
    for (let i = 1; i <= 20; i++) {
        if (i % 3 === 0) {
            contador++;  // Si el número es divisible por 3, aumentamos el contador
        }
    }
    console.log("Cantidad de números divisibles por 3: " + contador);
}

// Llamada a la función
numerosDivisiblesPorTres();
