//Calcular el area de un triangulo 
const areaTriangulo = (base, altura) => `El área del triángulo es: ${(base * altura) / 2}`;
console.log(areaTriangulo(5, 10));
