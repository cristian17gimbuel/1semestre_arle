//division de numeros
const dividir = (a, b) => 
    b !== 0 ? `La división de ${a} entre ${b} es: ${a / b}` : "No se puede dividir por cero";

console.log(dividir(10, 2));
console.log(dividir(5, 0));
