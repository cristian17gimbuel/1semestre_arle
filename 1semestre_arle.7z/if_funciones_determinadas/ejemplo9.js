//Registro de poyo sostenible
let estrato=2
let edad=18
let nombre="Cristian"
if(estrato>=3 && edad>=18){
    console.log(`${nombre}usted ha sido elegido para los apoyos sostenibles del gobierno actual`)
}else{
    console.log(`${nombre} usted no es beneficiario, gracias por su participacion `)
}