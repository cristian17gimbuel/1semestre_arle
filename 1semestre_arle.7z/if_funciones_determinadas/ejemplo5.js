//Control de baño
let bañodisponible = true
let nombrebaño= "Men"
if(bañodisponible){
    console.log(`El baño ${nombrebaño} SI esta disponible`)
}else{
    console.log(`El baño ${nombrebaño} NO esta disponible`)
}