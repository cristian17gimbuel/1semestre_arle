//Temperatura  colombia
let temcolombiana= 32
let climaestable=27
if (temcolombiana > climaestable){
    console.log(`La temperatura es  ${temcolombiana}°C por lo tanto el dia esta caloroso`)
}else{
    console.log(`La temperatura es ${temcolombiana}°C por lo tanto el dia esta nublado y frio  `)
}