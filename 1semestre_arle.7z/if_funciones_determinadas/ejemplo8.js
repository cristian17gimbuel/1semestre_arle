//Manejo de hotel
let estrato=1
if(estrato<=2){
    console.log(`Su estrato es ${estrato}, usted tendra acceso a las habitaciones normales`)
}else if(estrato>=3){
    console.log(`Su estrato es ${estrato}, usted tendra acceso a las habitaciones VIP`)
}else{
    console.log(`Su estrato es ${estrato}, no podras ingresar al hotel `)
}