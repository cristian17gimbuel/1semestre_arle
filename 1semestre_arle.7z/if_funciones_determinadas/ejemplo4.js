// Saber si es multiplo o no 
let numero=6
if (numero % 2==0){
    console.log(`El ${numero} es multiplo de 2`)
}else{
    console.log(`El ${numero} NO es multiplo de 2`)
}