//Manejo de decisiones simples // if else elseif 
let colorsemaforo= "rojo"
let estadosemaforo= true
if(estadosemaforo){
    if (colorsemaforo=="verde")
        console.log(`El semaforo esta en ${colorsemaforo}, puede avanzar`)
}else if(colorsemaforo=="amarillo"){
    console.log(`El semaforo esta en ${colorsemaforo} preparese`)
}else if(colorsemaforo=="rojo"){
    console.log(`El semaforo esta en ${colorsemaforo} no puede avanzar`)
}else {
    console.log(`El semaforo esta dañado`)
}