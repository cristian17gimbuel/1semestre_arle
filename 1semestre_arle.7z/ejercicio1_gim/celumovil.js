//Pago de linea internet
let operador = "Claro"
let minutosInternacionales = 10

let cargoFijo, valorMinuto, valorPaqueteDatos;

if (operador === "Tigo") {
    cargoFijo = 45000
    valorMinuto = 200
    valorPaqueteDatos = 12000
} else if (operador === "Claro") {
    cargoFijo = 30000
    valorMinuto = 100
    valorPaqueteDatos = 18000
} else if (operador === "Movistar") {
    cargoFijo = 40000
    valorMinuto = 250
    valorPaqueteDatos = 8000
} else {
    console.log("Operador no válido")
    return;
}

let costoLlamadas = minutosInternacionales * valorMinuto
let totalPagar = cargoFijo + costoLlamadas + valorPaqueteDatos

console.log(`Operador: ${operador}`)
console.log(`Cargo fijo: $${cargoFijo}`)
console.log(`Costo llamadas internacionales: $${costoLlamadas}`)
console.log(`Valor paquete de datos: $${valorPaqueteDatos}`)
console.log(`Total a pagar: $${totalPagar}`)