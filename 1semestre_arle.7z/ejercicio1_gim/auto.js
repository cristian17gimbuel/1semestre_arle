//Modelo defectuoso
let numeroModelo = 7080

if (numeroModelo === 119) {
    console.log("El automóvil está defectuoso, llevar a garantía.");
} else if (numeroModelo === 179) {
    console.log("El automóvil está defectuoso, llevar a garantía.");
} else if (numeroModelo >= 189 && numeroModelo <= 195) {
    console.log("El automóvil está defectuoso, llevar a garantía.");
} else if (numeroModelo === 221) {
    console.log("El automóvil está defectuoso, llevar a garantía.");
} else if (numeroModelo === 780) {
    console.log("El automóvil está defectuoso, llevar a garantía.");
} else {
    console.log("Su automóvil no está defectuoso.");
}
