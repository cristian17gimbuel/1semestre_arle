//Pago copias
let numerocopia=751
if(numerocopia==0 || numerocopia<=499){
    console.log(`Por imprimir son:${numerocopia} copias`)
    console.log(`El precio por cada copia es de $120pesos`)
    let pago1=(numerocopia*120)
    console.log(`El total a pagar es: ${pago1}`)
}else if(numerocopia==500 || numerocopia<=749){
    console.log(`Por imprimir son:${numerocopia} copias`)
    console.log(`El precio por cada copia es de $100pesos`)
    let pago2=(numerocopia*100)
    console.log(`El total a pagar es: ${pago2}`)
}else if(numerocopia==750 || numerocopia<=999){
    console.log(`Por imprimir son:${numerocopia} copias`)
    console.log(`El precio por cada copia es de $80pesos`)
    let pago3=(numerocopia*80)
    console.log(`El total a pagar es: ${pago3}`)
}else if(numerocopia==1000 || numerocopia>1000){
    console.log(`Por imprimir son:${numerocopia} copias`)
    console.log(`El precio por cada copia es de $50pesos`)
    let pago4=(numerocopia*50)
    console.log(`El total a pagar es: ${pago4}`)
}else{
    console.log(`Vaya a otro lado`)
}