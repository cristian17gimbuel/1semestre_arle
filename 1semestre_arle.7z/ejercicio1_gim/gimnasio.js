// Gimnasio
let dias = 10
let costo = 0

if (dias === 15) {
    costo = 18000
} else if (dias === 30) {
    costo = 35000
} else if (dias === 90) {
    costo = 86000
} else {
    console.log("Número de días no válido. Por favor, elija 15, 30 o 90.")
}

if (costo > 0) {
    console.log(`El costo a pagar por ${dias} días de gimnasio es: $${costo}`)
}
let angulo1 = 60
let angulo2 = 60
let angulo3 = 60
if (angulo1 + angulo2 + angulo3 === 180) {
    console.log("El triángulo es válido.")
} else {
    console.log("El triángulo no es válido.")
}