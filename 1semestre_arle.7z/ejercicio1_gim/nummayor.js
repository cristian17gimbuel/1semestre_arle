// Encontrar el número mayor entre tres números
let num1 = 5
let num2 = 7
let num3 =9
// Determinar el número mayor
let mayor;
if (num1 >= num2 && num1 >= num3) {
    mayor = num1
} else if (num2 >= num1 && num2 >= num3) {
    mayor = num2
} else {
    mayor = num3
    console.log(`El número mayor es: ${mayor}`)
}