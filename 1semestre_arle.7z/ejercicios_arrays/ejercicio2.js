//Precios altos
let precio=[1010,900,244,265,400,570,909,1600,7800,6000]
const filtrarprecios=precio.filter(x=> x>1000)
console.log("A continuacion se motraran productos cuyo precio es mayor de 1000mil pesos")
console.log(filtrarprecios)